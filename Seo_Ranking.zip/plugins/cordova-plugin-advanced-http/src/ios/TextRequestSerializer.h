#import <Foundation/Foundation.h>
#import "AFURLRequestSerialization.h"

@interface TextRequestSerializer : AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
